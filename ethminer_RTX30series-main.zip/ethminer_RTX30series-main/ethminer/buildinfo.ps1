$env:project_name="ethminer"
$env:project_version="0.19.0-16+commit.47ae149e"
$env:project_version_is_prerelease="true"
$env:system_name='linux'
$env:system_processor='x86_64'
